# Lodinka account + installable website starter

This starter adds sign-up, login, persistent Supabase sessions, an online user profile table, and PWA install support. It is not a complete Roblox recreation and it does not include native APK/IPA/EXE installers. PWA installation makes the website app-like on supported browsers.

## 1. Connect the online account system
1. Create a project at https://supabase.com/ (free tier availability/limits can change).
2. In the Supabase project, open **SQL Editor**, create a query, paste all of `supabase.sql`, and run it.
3. Open **Project Settings → API** (or API Keys). Copy the **Project URL** and the **publishable/anon key** only.
4. Open `index.html` and replace these two placeholders near the bottom:
   - `YOUR_SUPABASE_PROJECT_URL`
   - `YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY`
5. Never put a `service_role` or secret key in `index.html`.
6. In Supabase **Authentication → URL Configuration**, add your GitHub Pages URL to the allowed Site URL/Redirect URLs, for example `https://YOUR-GITHUB-USERNAME.github.io/lodinka/`.
7. If email confirmation is enabled, new users must click the confirmation email before they can log in. Configure SMTP if your project requires it for reliable delivery.

## 2. Publish on GitHub Pages from Android
1. Extract this ZIP on your phone.
2. Open your `lodinka` repository on GitHub.
3. Upload the files *inside* this folder to the repository root: `index.html`, `manifest.json`, `sw.js`, `supabase.sql`, and `README.md`. Do not upload only the ZIP.
4. Commit the files. In **Settings → Pages**, choose deploy from `main` and `/(root)` if not already enabled.
5. Open your Pages URL over HTTPS. Sign up with an email you can access, then log in. Test a second account separately.

## 3. Install on devices
- Android: supported browsers offer Install app or Add to Home screen.
- iPhone/iPad: open in Safari → Share → Add to Home Screen.
- Windows: supported Edge/Chrome → browser menu → Install app.
- MacBook: supported Chrome/Edge install option; Safari may offer Add to Dock depending on macOS version.

PWA installation depends on browser and OS support. Native Android APK, iOS App Store app, macOS app, and Windows executable require separate packaging/distribution work.

## Notes
- Accounts and profiles are stored online via Supabase after configuration; passwords are handled by Supabase Auth and are not stored in the profiles table.
- This starter does not yet save game progress, friend lists, chats, or game uploads.
- Keep the project URL and public anon/publishable key in the frontend; database security depends on Row Level Security policies. Never expose a service-role/secret key.
