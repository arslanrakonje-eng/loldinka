# Lodinka Classic — GitHub Pages starter

This is a single-file, mobile-friendly prototype with three selectable visual themes:
- 2015 Classic-inspired
- 2019 Classic-inspired
- 2022 Modern-inspired

## Publish from Android
1. Download and extract `lodinka-classic-starter.zip` on your phone.
2. Open your GitHub repository named `lodinka`.
3. Upload **the `index.html` file inside the extracted folder** to the repository root. Do not upload only the ZIP and expect GitHub Pages to unpack it.
4. Commit the change. If GitHub says `index.html` already exists, choose to replace it so the new site overwrites the old page.
5. Repository Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/(root)` → Save.
6. Visit `https://arslanrakonje-eng.github.io/lodinka/` and wait a few minutes after publishing.

## What works
- Responsive home and game catalogue
- Era selector that changes the visual theme
- Small local browser game demos
- Simple block avatar colour editor
- Local demo profile, chat, and friend list stored in the browser

## Important limitations
This is **not the actual Roblox website or a complete Roblox 2015/2019/2022 recreation**. The era choices are visual themes. Profile, friends and chat are local demonstrations and do not sync to other people. Real secure accounts, cross-device chat, moderation, and live multiplayer need a backend and game servers. Do not enter real passwords. Lodinka is independent and is not affiliated with Roblox.
